package com.footwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class ConfigActivity : Activity() {

    private val BG = 0xFF0F1420.toInt()
    private val CARD2 = 0xFF26324D.toInt()
    private val TEXT = 0xFFEAF0FA.toInt()
    private val MUTED = 0xFF8A97AD.toInt()
    private val ON_ACCENT = 0xFF06121C.toInt()

    private var id = AppWidgetManager.INVALID_APPWIDGET_ID
    private val chosen = LinkedHashSet<String>()
    private var scale = 100
    private var alpha = 90
    private var accent = 0
    private var mode = 0
    private var favEdit: EditText? = null
    private var d = 1f

    private fun px(v: Int): Int = (v * d).toInt()

    private fun rounded(c: Int, r: Float): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = r
        g.setColor(c)
        return g
    }

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(0, px(4), 0, px(4))
        return v
    }

    private fun add(parent: LinearLayout, v: View, top: Int = 8) {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = px(top)
        parent.addView(v, lp)
    }

    private fun styleChip(v: TextView, slug: String) {
        val on = chosen.contains(slug)
        v.text = (if (on) "✓  " else "") + Leagues.name(slug)
        v.setTextColor(if (on) ON_ACCENT else TEXT)
        v.background = rounded(if (on) Draw.accents[accent] else CARD2, 12 * d)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setResult(RESULT_CANCELED)
        d = resources.displayMetrics.density
        id = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val cur = Store.load(this, id)
        chosen.addAll(cur.leagues)
        scale = (cur.scale * 100).toInt()
        alpha = (cur.alpha * 100).toInt()
        accent = cur.accent
        mode = cur.mode

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(px(20), px(24), px(20), px(40))
        col.addView(tv("Футбольный виджет", 26f, Draw.accents[accent], true))
        col.addView(tv("Покажет ближайшие матчи. Размер виджета меняется на рабочем столе: зажми его и потяни за края.", 13f, MUTED))

        add(col, tv("ЛИГИ", 12f, MUTED, true), 18)
        val chips = ArrayList<Pair<String, TextView>>()
        for ((slug, _) in Leagues.list) {
            val chip = TextView(this)
            chip.textSize = 15f
            chip.typeface = Typeface.DEFAULT_BOLD
            chip.gravity = Gravity.CENTER_VERTICAL
            chip.setPadding(px(16), px(13), px(16), px(13))
            chip.setOnClickListener {
                if (chosen.contains(slug)) chosen.remove(slug) else chosen.add(slug)
                styleChip(chip, slug)
            }
            styleChip(chip, slug)
            chips.add(Pair(slug, chip))
            add(col, chip, 6)
        }

        add(col, tv("ЧТО ПОКАЗЫВАТЬ", 12f, MUTED, true), 18)
        val modeNames = listOf("Ближайшие матчи", "Последние результаты")
        val modeChips = ArrayList<TextView>()
        fun styleModes() {
            for (i in modeChips.indices) {
                val on = i == mode
                modeChips[i].text = (if (on) "✓  " else "") + modeNames[i]
                modeChips[i].setTextColor(if (on) ON_ACCENT else TEXT)
                modeChips[i].background = rounded(if (on) Draw.accents[accent] else CARD2, 12 * d)
            }
        }
        for (i in modeNames.indices) {
            val chip = TextView(this)
            chip.textSize = 15f
            chip.typeface = Typeface.DEFAULT_BOLD
            chip.gravity = Gravity.CENTER_VERTICAL
            chip.setPadding(px(16), px(13), px(16), px(13))
            chip.setOnClickListener {
                mode = i
                styleModes()
            }
            modeChips.add(chip)
            add(col, chip, 6)
        }
        styleModes()

        add(col, tv("ИЗБРАННЫЕ КОМАНДЫ", 12f, MUTED, true), 18)
        val fe = EditText(this)
        fe.setText(cur.favs)
        fe.hint = "Арсенал, Реал, Зенит… (через запятую)"
        fe.setTextColor(TEXT)
        fe.setHintTextColor(MUTED)
        fe.textSize = 15f
        fe.setPadding(px(16), px(13), px(16), px(13))
        fe.background = rounded(CARD2, 12 * d)
        fe.setSingleLine(false)
        favEdit = fe
        add(col, fe, 6)
        add(col, tv("Если заполнено, показываются только матчи этих команд. Можно по-русски (для популярных клубов) или по-английски, как в ESPN: Man United, PSG.", 12f, MUTED), 4)

        val scaleLabel = tv("", 14f, TEXT)
        val scaleBar = SeekBar(this)
        scaleBar.max = 80
        scaleBar.progress = (scale - 70).coerceIn(0, 80)
        scaleLabel.text = "Размер текста: $scale%"
        scaleBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                scale = 70 + p
                scaleLabel.text = "Размер текста: $scale%"
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        add(col, scaleLabel, 20)
        add(col, scaleBar, 0)

        val alphaLabel = tv("", 14f, TEXT)
        val alphaBar = SeekBar(this)
        alphaBar.max = 80
        alphaBar.progress = (alpha - 20).coerceIn(0, 80)
        alphaLabel.text = "Непрозрачность фона: $alpha%"
        alphaBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                alpha = 20 + p
                alphaLabel.text = "Непрозрачность фона: $alpha%"
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        add(col, alphaLabel, 14)
        add(col, alphaBar, 0)

        add(col, tv("ЦВЕТ АКЦЕНТА", 12f, MUTED, true), 18)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val dots = ArrayList<View>()
        fun styleDots() {
            for (i in dots.indices) {
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                g.setColor(Draw.accents[i])
                if (i == accent) g.setStroke(px(3), 0xFFFFFFFF.toInt())
                dots[i].background = g
            }
            for ((slug, chip) in chips) styleChip(chip, slug)
            styleModes()
        }
        for (i in Draw.accents.indices) {
            val dot = View(this)
            dot.setOnClickListener {
                accent = i
                styleDots()
            }
            dots.add(dot)
            val lp = LinearLayout.LayoutParams(px(44), px(44))
            lp.rightMargin = px(12)
            row.addView(dot, lp)
        }
        styleDots()
        add(col, row, 8)

        val ok = tv("Готово", 16f, ON_ACCENT, true)
        ok.gravity = Gravity.CENTER
        ok.setPadding(0, px(14), 0, px(14))
        ok.setOnClickListener { save() }
        ok.background = rounded(Draw.accents[0], 14 * d)
        add(col, ok, 26)

        val sv = ScrollView(this)
        sv.setBackgroundColor(BG)
        sv.addView(col)
        setContentView(sv)
    }

    private fun save() {
        val list = if (chosen.isEmpty()) listOf("eng.1") else chosen.toList()
        Store.save(this, id, list, scale, alpha, accent, mode, favEdit?.text?.toString() ?: "")
        FootWidget.update(this, intArrayOf(id), true)
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
        finish()
    }
}
