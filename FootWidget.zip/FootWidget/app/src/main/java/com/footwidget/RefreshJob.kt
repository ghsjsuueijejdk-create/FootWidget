package com.footwidget

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context

/** Фоновое обновление расписания раз в ~30 минут: работает и когда виджет давно не трогали. */
class RefreshJob : android.app.job.JobService() {

    override fun onStartJob(p: JobParameters): Boolean {
        val app = applicationContext
        val ids = AppWidgetManager.getInstance(app)
            .getAppWidgetIds(ComponentName(app, FootWidget::class.java))
        if (ids.isEmpty()) return false
        FootWidget.update(app, ids, true) { jobFinished(p, false) }
        return true
    }

    override fun onStopJob(p: JobParameters): Boolean = true

    companion object {
        private const val JOB_ID = 4201

        fun schedule(ctx: Context) {
            try {
                val js = ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
                if (js.getPendingJob(JOB_ID) != null) return
                val info = JobInfo.Builder(JOB_ID, ComponentName(ctx, RefreshJob::class.java))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPeriodic(30 * 60 * 1000L)
                    .setPersisted(true)
                    .build()
                js.schedule(info)
            } catch (t: Throwable) {
            }
        }

        fun cancel(ctx: Context) {
            try {
                (ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler).cancel(JOB_ID)
            } catch (t: Throwable) {
            }
        }
    }
}
