package com.footwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Экран приложения: подсказка, кнопка «Добавить виджет» и быстрый переход к настройкам фона. */
class MainActivity : Activity() {

    private val BG = 0xFF0F1420.toInt()
    private val CARD = 0xFF1A2236.toInt()
    private val TEXT = 0xFFEAF0FA.toInt()
    private val MUTED = 0xFF8A97AD.toInt()
    private val ACCENT = 0xFF5BD6FF.toInt()
    private val ON_ACCENT = 0xFF06121C.toInt()
    private var d = 1f

    private fun px(v: Int): Int = (v * d).toInt()

    private fun rounded(c: Int, r: Float): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = r
        g.setColor(c)
        return g
    }

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun add(parent: LinearLayout, v: View, top: Int = 12) {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = px(top)
        parent.addView(v, lp)
    }

    private fun button(text: String, primary: Boolean, onClick: () -> Unit): TextView {
        val b = tv(text, 16f, if (primary) ON_ACCENT else TEXT, true)
        b.gravity = Gravity.CENTER
        b.setPadding(px(16), px(14), px(16), px(14))
        b.background = rounded(if (primary) ACCENT else CARD, px(14).toFloat())
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d = resources.displayMetrics.density
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        root.setPadding(px(22), px(48), px(22), px(28))

        add(root, tv("⚽  Футбол", 28f, TEXT, true), 0)
        add(root, tv("Виджет с ближайшими матчами: логотипы, время по вашему поясу, счёт и минута.", 15f, MUTED), 6)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = rounded(CARD, px(16).toFloat())
        card.setPadding(px(18), px(16), px(18), px(16))
        add(card, tv("Как добавить", 16f, TEXT, true), 0)
        add(card, tv("1. Нажмите «Добавить виджет» ниже\n   (или долгое нажатие на рабочем столе → «Виджеты» → «Футбол»).\n2. Выберите лиги, размер и цвет.\n3. Нажатие на виджет — обновить данные.", 14f, MUTED), 8)
        add(root, card, 22)

        add(root, button("Добавить виджет на рабочий стол", true) { pinWidget() }, 22)
        add(root, button("Работа в фоне (автозапуск, экономия заряда)", false) { openAppSettings() }, 12)
        add(root, tv("На Xiaomi/MIUI включите «Автозапуск» и поставьте «Без ограничений» в экономии заряда — иначе виджет может не обновляться.", 12f, MUTED), 10)

        val sv = ScrollView(this)
        sv.setBackgroundColor(BG)
        sv.addView(root)
        setContentView(sv)
    }

    private fun pinWidget() {
        val mgr = AppWidgetManager.getInstance(this)
        if (mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, FootWidget::class.java), null, null)
        } else {
            Toast.makeText(
                this,
                "Долгое нажатие на рабочем столе → «Виджеты» → «Футбол»",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun openAppSettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
        }
    }
}
