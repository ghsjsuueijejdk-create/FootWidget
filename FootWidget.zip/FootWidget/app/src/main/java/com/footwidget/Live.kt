package com.footwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent

/** Частое обновление только пока идёт матч (или к началу ближайшего). */
object Live {
    private const val CODE = 777001

    private fun pi(ctx: Context): PendingIntent {
        val i = Intent(ctx, FootWidget::class.java)
        i.action = FootWidget.ACTION_LIVE
        return PendingIntent.getBroadcast(ctx, CODE, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun cancel(ctx: Context) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(pi(ctx.applicationContext))
        } catch (t: Throwable) {
        }
    }

    fun schedule(ctx: Context) {
        try {
            val app = ctx.applicationContext
            val am = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val ids = AppWidgetManager.getInstance(app)
                .getAppWidgetIds(ComponentName(app, FootWidget::class.java))
            if (ids.isEmpty()) {
                am.cancel(pi(app))
                return
            }
            val leagues = HashSet<String>()
            for (id in ids) leagues.addAll(Store.load(app, id).leagues)
            val at = Store.nextTick(app, leagues.toList(), System.currentTimeMillis())
            if (at == null) {
                am.cancel(pi(app))
                return
            }
            // неточный будильник: разрешений не требует, в Doze может сработать позже
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(app))
        } catch (t: Throwable) {
        }
    }
}
