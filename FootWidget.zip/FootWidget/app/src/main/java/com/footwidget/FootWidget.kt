package com.footwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.widget.RemoteViews
import kotlin.math.max

class FootWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val pr = goAsync()
        update(ctx, ids) { pr.finish() }
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, o: Bundle) {
        drawOne(ctx, mgr, id)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        for (i in ids) Store.delete(ctx, i)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == ACTION_NEXT || intent.action == ACTION_PREV) {
            val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
            if (id >= 0) {
                val delta = if (intent.action == ACTION_NEXT) 1 else -1
                Store.setPage(ctx, id, Store.page(ctx, id) + delta)
                drawOne(ctx, AppWidgetManager.getInstance(ctx), id)
            }
            return
        }
        if (intent.action == ACTION_REFRESH) {
            val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = if (id >= 0) intArrayOf(id)
            else mgr.getAppWidgetIds(ComponentName(ctx, FootWidget::class.java))
            val pr = goAsync()
            update(ctx, ids) { pr.finish() }
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.footwidget.REFRESH"
        const val ACTION_NEXT = "com.footwidget.NEXT"
        const val ACTION_PREV = "com.footwidget.PREV"

        private fun pi(ctx: Context, id: Int, action: String, n: Int): PendingIntent {
            val i = Intent(ctx, FootWidget::class.java)
            i.action = action
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            return PendingIntent.getBroadcast(
                ctx, id * 4 + n, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        /** Сразу рисует из кэша, потом в фоне загружает свежие данные и перерисовывает. */
        fun update(ctx: Context, ids: IntArray, onDone: (() -> Unit)? = null) {
            val app = ctx.applicationContext
            val mgr = AppWidgetManager.getInstance(app)
            for (id in ids) drawOne(app, mgr, id)
            Thread {
                try {
                    val leagues = HashSet<String>()
                    for (id in ids) leagues.addAll(Store.load(app, id).leagues)
                    var ok = false
                    for (l in leagues) if (Football.refresh(app, l)) ok = true
                    if (ok) Store.touch(app)
                    // сначала показываем матчи, потом докачиваем логотипы
                    for (id in ids) drawOne(app, mgr, id)
                    for (l in leagues) Football.loadLogos(app, l)
                    for (id in ids) drawOne(app, mgr, id)
                } catch (t: Throwable) {
                } finally {
                    onDone?.invoke()
                }
            }.start()
        }

        fun drawOne(ctx: Context, mgr: AppWidgetManager, id: Int) {
            try {
                val o = mgr.getAppWidgetOptions(id)
                val port = ctx.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
                val wDp = if (port) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250)
                else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 250)
                val hDp = if (port) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 110)
                else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110)
                val bm = Draw.render(ctx, id, max(wDp, 60), max(hDp, 40))
                val rv = RemoteViews(ctx.packageName, R.layout.widget)
                rv.setImageViewBitmap(R.id.img, bm)
                rv.setOnClickPendingIntent(R.id.img, pi(ctx, id, ACTION_REFRESH, 0))
                val multi = Store.pageCount(ctx, id) > 1
                val vis = if (multi) android.view.View.VISIBLE else android.view.View.GONE
                rv.setViewVisibility(R.id.prev, vis)
                rv.setViewVisibility(R.id.next, vis)
                rv.setOnClickPendingIntent(R.id.prev, pi(ctx, id, ACTION_PREV, 1))
                rv.setOnClickPendingIntent(R.id.next, pi(ctx, id, ACTION_NEXT, 2))
                mgr.updateAppWidget(id, rv)
            } catch (t: Throwable) {
            }
        }
    }
}
