package com.footwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.widget.RemoteViews
import kotlin.math.max

class FootWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val pr = goAsync()
        update(ctx, ids) { pr.finish() }
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, o: Bundle) {
        drawOne(ctx, mgr, id)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        for (i in ids) Store.delete(ctx, i)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == ACTION_REFRESH) {
            val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = if (id >= 0) intArrayOf(id)
            else mgr.getAppWidgetIds(ComponentName(ctx, FootWidget::class.java))
            val pr = goAsync()
            update(ctx, ids) { pr.finish() }
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.footwidget.REFRESH"

        /** Сразу рисует из кэша, потом в фоне загружает свежие данные и перерисовывает. */
        fun update(ctx: Context, ids: IntArray, onDone: (() -> Unit)? = null) {
            val app = ctx.applicationContext
            val mgr = AppWidgetManager.getInstance(app)
            for (id in ids) drawOne(app, mgr, id)
            Thread {
                try {
                    val leagues = HashSet<String>()
                    for (id in ids) leagues.addAll(Store.load(app, id).leagues)
                    var ok = false
                    for (l in leagues) if (Football.refresh(app, l)) ok = true
                    if (ok) Store.touch(app)
                    for (id in ids) drawOne(app, mgr, id)
                } catch (t: Throwable) {
                } finally {
                    onDone?.invoke()
                }
            }.start()
        }

        fun drawOne(ctx: Context, mgr: AppWidgetManager, id: Int) {
            try {
                val o = mgr.getAppWidgetOptions(id)
                val port = ctx.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
                val wDp = if (port) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250)
                else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 250)
                val hDp = if (port) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 110)
                else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110)
                val bm = Draw.render(ctx, id, max(wDp, 60), max(hDp, 40))
                val rv = RemoteViews(ctx.packageName, R.layout.widget)
                rv.setImageViewBitmap(R.id.img, bm)
                val i = Intent(ctx, FootWidget::class.java)
                i.action = ACTION_REFRESH
                i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                val pi = PendingIntent.getBroadcast(
                    ctx, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                rv.setOnClickPendingIntent(R.id.img, pi)
                mgr.updateAppWidget(id, rv)
            } catch (t: Throwable) {
            }
        }
    }
}
