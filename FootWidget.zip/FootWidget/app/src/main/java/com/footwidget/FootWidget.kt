package com.footwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.RemoteViews
import kotlin.math.max

class FootWidget : AppWidgetProvider() {

    override fun onEnabled(ctx: Context) {
        RefreshJob.schedule(ctx)
    }

    override fun onDisabled(ctx: Context) {
        RefreshJob.cancel(ctx)
        Live.cancel(ctx)
    }

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        RefreshJob.schedule(ctx)
        val pr = goAsync()
        update(ctx, ids, true) { pr.finish() }
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, o: Bundle) {
        drawOne(ctx, mgr, id)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        for (i in ids) Store.delete(ctx, i)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        val act = intent.action
        if (act == ACTION_NEXT || act == ACTION_PREV) {
            val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
            if (id >= 0) {
                val delta = if (act == ACTION_NEXT) 1 else -1
                Store.setPage(ctx, id, Store.page(ctx, id) + delta)
                drawOne(ctx, AppWidgetManager.getInstance(ctx), id)
            }
            return
        }
        if (act == ACTION_MODE) {
            val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
            if (id >= 0) {
                Store.setMode(ctx, id, 1 - Store.mode(ctx, id))
                Store.setPage(ctx, id, 0)
                drawOne(ctx, AppWidgetManager.getInstance(ctx), id)
            }
            return
        }
        if (act == ACTION_LIVE) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, FootWidget::class.java))
            if (ids.isEmpty()) {
                Live.cancel(ctx)
                return
            }
            val pr = goAsync()
            update(ctx, ids, false) { pr.finish() }
            return
        }
        if (act == ACTION_REFRESH) {
            val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = if (id >= 0) intArrayOf(id)
            else mgr.getAppWidgetIds(ComponentName(ctx, FootWidget::class.java))
            val pr = goAsync()
            // пока данных нет совсем — полная загрузка, потом достаточно лёгкого обновления
            update(ctx, ids, Store.lastUpdate(ctx) == 0L) { pr.finish() }
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.footwidget.REFRESH"
        const val ACTION_NEXT = "com.footwidget.NEXT"
        const val ACTION_PREV = "com.footwidget.PREV"
        const val ACTION_MODE = "com.footwidget.MODE"
        const val ACTION_LIVE = "com.footwidget.LIVE"

        private val ROW_OUT = intArrayOf(
            R.id.zr0, R.id.zr1, R.id.zr2, R.id.zr3, R.id.zr4, R.id.zr5,
            R.id.zr6, R.id.zr7, R.id.zr8, R.id.zr9, R.id.zr10, R.id.zr11
        )
        private val ROW_IN = intArrayOf(
            R.id.zc0, R.id.zc1, R.id.zc2, R.id.zc3, R.id.zc4, R.id.zc5,
            R.id.zc6, R.id.zc7, R.id.zc8, R.id.zc9, R.id.zc10, R.id.zc11
        )

        private fun pi(ctx: Context, id: Int, action: String, n: Int): PendingIntent {
            val i = Intent(ctx, FootWidget::class.java)
            i.action = action
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            return PendingIntent.getBroadcast(
                ctx, id * 4 + n, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun openPi(ctx: Context, id: Int, row: Int, url: String): PendingIntent {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return PendingIntent.getActivity(
                ctx, 1_000_000 + id * 32 + row, i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        /**
         * Сразу рисует из кэша, потом в фоне загружает данные и перерисовывает.
         * full = true: всё расписание (−4…+10 дней) и логотипы; false: только вчера-сегодня-завтра (живой счёт).
         * В конце планирует следующее «живое» обновление, если идёт матч.
         */
        fun update(ctx: Context, ids: IntArray, full: Boolean, onDone: (() -> Unit)? = null) {
            val app = ctx.applicationContext
            val mgr = AppWidgetManager.getInstance(app)
            for (id in ids) drawOne(app, mgr, id)
            Thread {
                try {
                    val leagues = HashSet<String>()
                    for (id in ids) leagues.addAll(Store.load(app, id).leagues)
                    var ok = false
                    for (l in leagues) {
                        val r = if (full) Football.refresh(app, l) else Football.refreshLive(app, l)
                        if (r) ok = true
                    }
                    if (ok) Store.touch(app)
                    // сначала показываем матчи, потом докачиваем логотипы
                    for (id in ids) drawOne(app, mgr, id)
                    if (full) {
                        for (l in leagues) Football.loadLogos(app, l)
                        for (id in ids) drawOne(app, mgr, id)
                    }
                } catch (t: Throwable) {
                } finally {
                    Live.schedule(app)
                    onDone?.invoke()
                }
            }.start()
        }

        fun drawOne(ctx: Context, mgr: AppWidgetManager, id: Int) {
            try {
                val o = mgr.getAppWidgetOptions(id)
                val port = ctx.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
                val wDp = if (port) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250)
                else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 250)
                val hDp = if (port) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 110)
                else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110)
                val r = Draw.render(ctx, id, max(wDp, 60), max(hDp, 40))
                val rv = RemoteViews(ctx.packageName, R.layout.widget)
                rv.setImageViewBitmap(R.id.img, r.bm)
                rv.setOnClickPendingIntent(R.id.img, pi(ctx, id, ACTION_REFRESH, 0))

                // координаты в картинке → пиксели виджета (картинка может быть уменьшена на k)
                val inv = 1f / r.k
                val bw = r.bm.width.toFloat()
                val bh = r.bm.height.toFloat()

                // заголовок: переключение «Матчи / Итоги»
                if (r.headerBottom > 0f) {
                    rv.setViewVisibility(R.id.zh, View.VISIBLE)
                    rv.setViewPadding(
                        R.id.zh, 0, 0,
                        max(0, ((bw - r.toggleRight) * inv).toInt()),
                        max(0, ((bh - r.headerBottom) * inv).toInt())
                    )
                    rv.setOnClickPendingIntent(R.id.zhc, pi(ctx, id, ACTION_MODE, 3))
                } else {
                    rv.setViewVisibility(R.id.zh, View.GONE)
                }

                // строки матчей: нажатие открывает страницу матча
                val side = (r.pad * inv).toInt()
                for (i in ROW_OUT.indices) {
                    val z = if (i < r.rows.size) r.rows[i] else null
                    if (z != null && z.url.isNotEmpty()) {
                        rv.setViewVisibility(ROW_OUT[i], View.VISIBLE)
                        rv.setViewPadding(
                            ROW_OUT[i], side, (z.top * inv).toInt(),
                            side, max(0, ((bh - z.bottom) * inv).toInt())
                        )
                        rv.setOnClickPendingIntent(ROW_IN[i], openPi(ctx, id, i, z.url))
                    } else {
                        rv.setViewVisibility(ROW_OUT[i], View.GONE)
                    }
                }

                // листание (ниже заголовка)
                rv.setViewPadding(R.id.znav, 0, (r.headerBottom * inv).toInt(), 0, 0)
                val multi = Store.pageCount(ctx, id) > 1
                val vis = if (multi) View.VISIBLE else View.GONE
                rv.setViewVisibility(R.id.prev, vis)
                rv.setViewVisibility(R.id.next, vis)
                rv.setOnClickPendingIntent(R.id.prev, pi(ctx, id, ACTION_PREV, 1))
                rv.setOnClickPendingIntent(R.id.next, pi(ctx, id, ACTION_NEXT, 2))
                mgr.updateAppWidget(id, rv)
            } catch (t: Throwable) {
            }
        }
    }
}
