package com.footwidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class Zone(val top: Float, val bottom: Float, val url: String)

class Rendered(
    val bm: Bitmap,
    val k: Float,
    val pad: Float,
    val headerBottom: Float,
    val toggleRight: Float,
    val rows: List<Zone>
)

/** Рисует весь виджет одной картинкой под нужный размер. */
object Draw {
    val accents = intArrayOf(0xFF4FC3F7.toInt(), 0xFF4CD08B.toInt(), 0xFFFFA24C.toInt(), 0xFFFF6FAE.toInt())
    private val TEXT = 0xFFEAF0FA.toInt()
    private val MUTED = 0xFF8A97AD.toInt()
    private val LIVE = 0xFFFF6B6B.toInt()

    private fun dayLabel(ts: Long): String {
        val now = Calendar.getInstance()
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        fun key(x: Calendar) = x.get(Calendar.YEAR) * 1000 + x.get(Calendar.DAY_OF_YEAR)
        if (key(c) == key(now)) return "Сегодня"
        val yest = Calendar.getInstance()
        yest.add(Calendar.DAY_OF_YEAR, -1)
        if (key(c) == key(yest)) return "Вчера"
        now.add(Calendar.DAY_OF_YEAR, 1)
        if (key(c) == key(now)) return "Завтра"
        return SimpleDateFormat("EEE, d MMM", Locale("ru")).format(Date(ts))
    }

    fun render(ctx: Context, id: Int, wDp: Int, hDp: Int): Rendered {
        val cfg = Store.load(ctx, id)
        val dens = ctx.resources.displayMetrics.density
        val k = min(1f, sqrt(1_400_000f / (wDp * dens * hDp * dens)))
        val d = dens * k
        val w = max(1, (wDp * d).toInt())
        val h = max(1, (hDp * d).toInt())
        val wf = w.toFloat()
        val hf = h.toFloat()
        val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bm)
        val ts = cfg.scale
        val accent = accents[cfg.accent.coerceIn(0, 3)]
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = Typeface.DEFAULT_BOLD

        p.color = ((0xEE * cfg.alpha).toInt() shl 24) or 0x0F1420
        cv.drawRoundRect(RectF(0f, 0f, wf, hf), 22 * d, 22 * d, p)

        val mode = cfg.mode
        val favOn = Store.favTokens(cfg.favs).isNotEmpty()
        val base = if (mode == 1) Store.results(ctx, cfg.leagues) else Store.upcoming(ctx, cfg.leagues)
        val all = Store.applyFavs(base, cfg.favs)
        val compact = hDp < 100
        val pad = if (compact) 8 * d else 12 * d
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        var y = pad

        var headerBottom = 0f
        var toggleRight = 0f
        if (!compact) {
            tp.color = accent
            tp.textSize = 13 * d * ts
            tp.textAlign = Paint.Align.LEFT
            val title = if (cfg.leagues.size == 1) Leagues.name(cfg.leagues[0]) else "Футбол"
            val t = TextUtils.ellipsize((if (favOn) "⚽ ★ " else "⚽ ") + title, tp, wf * 0.42f - pad, TextUtils.TruncateAt.END).toString()
            cv.drawText(t, pad, y + 12 * d * ts, tp)
            val tw = tp.measureText(t)
            // «таблетка» с режимом: нажатие по заголовку переключает матчи / результаты
            val lbl = if (mode == 1) "Итоги" else "Матчи"
            tp.textSize = 10 * d * ts
            val lw = tp.measureText(lbl)
            val px0 = pad + tw + 8 * d
            p.color = (0x40 shl 24) or (accent and 0xFFFFFF)
            cv.drawRoundRect(RectF(px0, y, px0 + lw + 12 * d, y + 16 * d * ts), 8 * d, 8 * d, p)
            tp.color = accent
            cv.drawText(lbl, px0 + 6 * d, y + 11.5f * d * ts, tp)
            toggleRight = min(wf, px0 + lw + 12 * d + pad)
            val upd = Store.lastUpdate(ctx)
            if (upd > 0) {
                tp.color = MUTED
                tp.textSize = 10 * d * ts
                tp.textAlign = Paint.Align.RIGHT
                cv.drawText("обновлено " + fmt.format(Date(upd)), wf - pad, y + 11 * d * ts, tp)
            }
            y += 24 * d * ts
            headerBottom = y
        }
        val zones = ArrayList<Zone>()

        val rowH = if (compact) hf - 2 * pad + 4 * d else 46 * d * ts
        val dayH = 16 * d * ts
        val y0 = y

        /** Делит матчи на страницы (максимум 5): [начало, конец) для каждой. */
        fun paginate(limit: Float): List<IntArray> {
            val res = ArrayList<IntArray>()
            var i = 0
            while (i < all.size && res.size < 5) {
                val start = i
                var yy = y0
                var last = ""
                var cnt = 0
                while (i < all.size) {
                    val day = dayLabel(all[i].ts)
                    val needDay = !compact && day != last
                    val need = rowH + (if (needDay) dayH else 0f)
                    if (yy + need > limit + 2 * d && cnt > 0) break
                    if (needDay) {
                        yy += dayH
                        last = day
                    }
                    yy += rowH
                    cnt++
                    i++
                }
                res.add(intArrayOf(start, i))
            }
            return res
        }

        var pgs = paginate(hf - pad)
        if (pgs.size > 1 && !compact) pgs = paginate(hf - pad - 14 * d)
        val pages = max(1, pgs.size)
        val page = ((Store.page(ctx, id) % pages) + pages) % pages
        Store.setPage(ctx, id, page)
        Store.setPageCount(ctx, id, pages)
        val from = if (pgs.isEmpty()) 0 else pgs[page][0]
        val to = if (pgs.isEmpty()) 0 else pgs[page][1]

        fun logo(url: String, x: Float, top: Float, size: Float) {
            val b = Logos.get(ctx, url, false) ?: return
            val sc = size / max(b.width, b.height).toFloat()
            val bw = b.width * sc
            val bh = b.height * sc
            val l = x + (size - bw) / 2
            val t = top + (size - bh) / 2
            cv.drawBitmap(b, null, RectF(l, t, l + bw, t + bh), bp)
        }

        fun fit(name: String, abbr: String, maxW: Float, narrow: Boolean): String {
            if (maxW < 18 * d) return ""
            var t = if (narrow && abbr.isNotEmpty()) abbr else name
            if (tp.measureText(t) > maxW && abbr.isNotEmpty()) t = abbr
            return TextUtils.ellipsize(t, tp, maxW, TextUtils.TruncateAt.END).toString()
        }

        val narrow = wDp < 230
        var lastDay = ""
        var shown = 0

        for (idx in from until to) {
            val m = all[idx]
            val day = dayLabel(m.ts)
            val needDay = !compact && day != lastDay
            if (needDay) {
                tp.color = MUTED
                tp.textSize = 10.5f * d * ts
                tp.textAlign = Paint.Align.LEFT
                cv.drawText(day.uppercase(Locale("ru")), pad + 2 * d, y + 11 * d * ts, tp)
                y += dayH
                lastDay = day
            }
            val top = y
            val bot = top + rowH - 4 * d
            if (zones.size < 12) zones.add(Zone(top, bot, m.url))
            p.color = ((0xCC * cfg.alpha).toInt() shl 24) or 0x1A2233
            cv.drawRoundRect(RectF(pad, top, wf - pad, bot), 12 * d, 12 * d, p)
            val cy = (top + bot) / 2
            val ls = min(26 * d * ts, (bot - top) * 0.72f)
            val cx = wf / 2
            val cw = 60 * d * ts

            tp.color = TEXT
            tp.textSize = 12.5f * d * ts
            val ty = cy + tp.textSize * 0.35f
            val hx = pad + 8 * d
            logo(m.hLogo, hx, cy - ls / 2, ls)
            val hStart = hx + ls + 6 * d
            tp.textAlign = Paint.Align.LEFT
            cv.drawText(fit(m.home, m.hAbbr, cx - cw / 2 - hStart - 2 * d, narrow), hStart, ty, tp)

            val ax = wf - pad - 8 * d - ls
            logo(m.aLogo, ax, cy - ls / 2, ls)
            val aEnd = ax - 6 * d
            tp.textAlign = Paint.Align.RIGHT
            cv.drawText(fit(m.away, m.aAbbr, aEnd - (cx + cw / 2 + 2 * d), narrow), aEnd, ty, tp)

            tp.textAlign = Paint.Align.CENTER
            tp.textSize = 16 * d * ts
            if (m.state == "in" || m.state == "post") {
                tp.color = TEXT
                cv.drawText("${m.hs} : ${m.aS}", cx, cy + tp.textSize * 0.1f, tp)
                tp.color = if (m.state == "in") LIVE else MUTED
                tp.textSize = 10 * d * ts
                cv.drawText(if (m.state == "in") m.clock else "ФТ", cx, cy + 16 * d * ts * 0.9f, tp)
            } else {
                tp.color = TEXT
                val base = if (compact) cy else cy + tp.textSize * 0.35f
                cv.drawText(fmt.format(Date(m.ts)), cx, base, tp)
                if (compact) {
                    tp.color = MUTED
                    tp.textSize = 10 * d * ts
                    cv.drawText(day, cx, cy + 15 * d * ts, tp)
                }
            }
            y += rowH
            shown++
        }

        if (pages > 1) {
            // точки страниц и стрелки: нажатие у левого/правого края листает
            val dy = if (compact) hf - 5 * d else hf - 9 * d
            val gap = 10 * d
            val x0 = wf / 2 - (pages - 1) * gap / 2
            tp.textSize = 14 * d
            tp.color = MUTED
            tp.textAlign = Paint.Align.RIGHT
            cv.drawText("‹", x0 - 8 * d, dy + 5 * d, tp)
            tp.textAlign = Paint.Align.LEFT
            cv.drawText("›", x0 + (pages - 1) * gap + 8 * d, dy + 5 * d, tp)
            for (i in 0 until pages) {
                p.color = if (i == page) accent else (0x66 shl 24) or 0x8A97AD
                cv.drawCircle(x0 + i * gap, dy, (if (i == page) 3f else 2.4f) * d, p)
            }
        }

        if (shown == 0) {
            tp.color = MUTED
            tp.textSize = 13 * d * ts
            tp.textAlign = Paint.Align.CENTER
            val err = Store.error(ctx)
            val msg = when {
                err.isNotEmpty() && Store.lastUpdate(ctx) == 0L -> "Нет данных (нажми — повтор)"
                Store.lastUpdate(ctx) == 0L -> "Загрузка…"
                favOn -> "Нет матчей избранных команд"
                mode == 1 -> "Нет завершённых матчей"
                else -> "Нет ближайших матчей"
            }
            cv.drawText(msg, wf / 2, hf / 2 + 5 * d, tp)
            if (err.isNotEmpty()) {
                tp.textSize = 9 * d * ts
                cv.drawText(err, wf / 2, hf / 2 + 20 * d * ts, tp)
            }
        }
        return Rendered(bm, k, pad, headerBottom, toggleRight, zones)
    }
}
