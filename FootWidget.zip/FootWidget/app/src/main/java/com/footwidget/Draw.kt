package com.footwidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Рисует весь виджет одной картинкой под нужный размер. */
object Draw {
    val accents = intArrayOf(0xFF4FC3F7.toInt(), 0xFF4CD08B.toInt(), 0xFFFFA24C.toInt(), 0xFFFF6FAE.toInt())
    private val TEXT = 0xFFEAF0FA.toInt()
    private val MUTED = 0xFF8A97AD.toInt()
    private val LIVE = 0xFFFF6B6B.toInt()

    private fun dayLabel(ts: Long): String {
        val now = Calendar.getInstance()
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        fun key(x: Calendar) = x.get(Calendar.YEAR) * 1000 + x.get(Calendar.DAY_OF_YEAR)
        if (key(c) == key(now)) return "Сегодня"
        now.add(Calendar.DAY_OF_YEAR, 1)
        if (key(c) == key(now)) return "Завтра"
        return SimpleDateFormat("EEE, d MMM", Locale("ru")).format(Date(ts))
    }

    fun render(ctx: Context, id: Int, wDp: Int, hDp: Int): Bitmap {
        val cfg = Store.load(ctx, id)
        val dens = ctx.resources.displayMetrics.density
        val k = min(1f, sqrt(1_400_000f / (wDp * dens * hDp * dens)))
        val d = dens * k
        val w = max(1, (wDp * d).toInt())
        val h = max(1, (hDp * d).toInt())
        val wf = w.toFloat()
        val hf = h.toFloat()
        val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bm)
        val ts = cfg.scale
        val accent = accents[cfg.accent.coerceIn(0, 3)]
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = Typeface.DEFAULT_BOLD

        p.color = ((0xEE * cfg.alpha).toInt() shl 24) or 0x0F1420
        cv.drawRoundRect(RectF(0f, 0f, wf, hf), 22 * d, 22 * d, p)

        val all = Store.upcoming(ctx, cfg.leagues)
        val compact = hDp < 100
        val pad = if (compact) 8 * d else 12 * d
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        var y = pad

        if (!compact) {
            tp.color = accent
            tp.textSize = 13 * d * ts
            tp.textAlign = Paint.Align.LEFT
            val title = if (cfg.leagues.size == 1) Leagues.name(cfg.leagues[0]) else "Футбол"
            cv.drawText("⚽ $title", pad, y + 12 * d * ts, tp)
            val upd = Store.lastUpdate(ctx)
            if (upd > 0) {
                tp.color = MUTED
                tp.textSize = 10 * d * ts
                tp.textAlign = Paint.Align.RIGHT
                cv.drawText("обновлено " + fmt.format(Date(upd)), wf - pad, y + 11 * d * ts, tp)
            }
            y += 24 * d * ts
        }

        fun logo(url: String, x: Float, top: Float, size: Float) {
            val b = Logos.get(ctx, url, false) ?: return
            val sc = size / max(b.width, b.height).toFloat()
            val bw = b.width * sc
            val bh = b.height * sc
            val l = x + (size - bw) / 2
            val t = top + (size - bh) / 2
            cv.drawBitmap(b, null, RectF(l, t, l + bw, t + bh), bp)
        }

        fun fit(name: String, abbr: String, maxW: Float, narrow: Boolean): String {
            if (maxW < 18 * d) return ""
            var t = if (narrow && abbr.isNotEmpty()) abbr else name
            if (tp.measureText(t) > maxW && abbr.isNotEmpty()) t = abbr
            return TextUtils.ellipsize(t, tp, maxW, TextUtils.TruncateAt.END).toString()
        }

        val rowH = if (compact) hf - 2 * pad + 4 * d else 46 * d * ts
        val dayH = 16 * d * ts
        val bottom = hf - pad
        val narrow = wDp < 230
        var lastDay = ""
        var shown = 0

        for (m in all) {
            val day = dayLabel(m.ts)
            val needDay = !compact && day != lastDay
            val need = rowH + (if (needDay) dayH else 0f)
            if (y + need > bottom + 2 * d && shown > 0) break
            if (needDay) {
                tp.color = MUTED
                tp.textSize = 10.5f * d * ts
                tp.textAlign = Paint.Align.LEFT
                cv.drawText(day.uppercase(Locale("ru")), pad + 2 * d, y + 11 * d * ts, tp)
                y += dayH
                lastDay = day
            }
            val top = y
            val bot = top + rowH - 4 * d
            p.color = ((0xCC * cfg.alpha).toInt() shl 24) or 0x1A2233
            cv.drawRoundRect(RectF(pad, top, wf - pad, bot), 12 * d, 12 * d, p)
            val cy = (top + bot) / 2
            val ls = min(26 * d * ts, (bot - top) * 0.72f)
            val cx = wf / 2
            val cw = 60 * d * ts

            tp.color = TEXT
            tp.textSize = 12.5f * d * ts
            val ty = cy + tp.textSize * 0.35f
            val hx = pad + 8 * d
            logo(m.hLogo, hx, cy - ls / 2, ls)
            val hStart = hx + ls + 6 * d
            tp.textAlign = Paint.Align.LEFT
            cv.drawText(fit(m.home, m.hAbbr, cx - cw / 2 - hStart - 2 * d, narrow), hStart, ty, tp)

            val ax = wf - pad - 8 * d - ls
            logo(m.aLogo, ax, cy - ls / 2, ls)
            val aEnd = ax - 6 * d
            tp.textAlign = Paint.Align.RIGHT
            cv.drawText(fit(m.away, m.aAbbr, aEnd - (cx + cw / 2 + 2 * d), narrow), aEnd, ty, tp)

            tp.textAlign = Paint.Align.CENTER
            tp.textSize = 16 * d * ts
            if (m.state == "in") {
                tp.color = TEXT
                cv.drawText("${m.hs} : ${m.aS}", cx, cy + tp.textSize * 0.1f, tp)
                tp.color = LIVE
                tp.textSize = 10 * d * ts
                cv.drawText(m.clock, cx, cy + 16 * d * ts * 0.9f, tp)
            } else {
                tp.color = TEXT
                val base = if (compact) cy else cy + tp.textSize * 0.35f
                cv.drawText(fmt.format(Date(m.ts)), cx, base, tp)
                if (compact) {
                    tp.color = MUTED
                    tp.textSize = 10 * d * ts
                    cv.drawText(day, cx, cy + 15 * d * ts, tp)
                }
            }
            y += rowH
            shown++
        }

        if (shown == 0) {
            tp.color = MUTED
            tp.textSize = 13 * d * ts
            tp.textAlign = Paint.Align.CENTER
            val msg = if (Store.lastUpdate(ctx) == 0L) "Загрузка…" else "Нет ближайших матчей"
            cv.drawText(msg, wf / 2, hf / 2 + 5 * d, tp)
        }
        return bm
    }
}
