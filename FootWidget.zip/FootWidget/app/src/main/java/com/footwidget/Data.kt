package com.footwidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.max

class Match(
    val ts: Long,
    val league: String,
    val home: String,
    val away: String,
    val hAbbr: String,
    val aAbbr: String,
    val hLogo: String,
    val aLogo: String,
    val state: String,
    val hs: String,
    val aS: String,
    val clock: String
)

class Settings(val leagues: List<String>, val scale: Float, val alpha: Float, val accent: Int)

object Leagues {
    val list = listOf(
        "eng.1" to "Премьер-лига",
        "esp.1" to "Ла Лига",
        "ger.1" to "Бундеслига",
        "ita.1" to "Серия A",
        "fra.1" to "Лига 1",
        "uefa.champions" to "Лига чемпионов",
        "uefa.europa" to "Лига Европы",
        "rus.1" to "РПЛ",
        "fifa.world" to "Чемпионат мира"
    )

    fun name(slug: String): String = list.firstOrNull { it.first == slug }?.second ?: slug
}

object Store {
    private fun sp(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("foot", Context.MODE_PRIVATE)

    fun load(ctx: Context, id: Int): Settings {
        val p = sp(ctx)
        val ls = (p.getString("lg_$id", "eng.1") ?: "eng.1").split(",").filter { it.isNotEmpty() }
        return Settings(
            if (ls.isEmpty()) listOf("eng.1") else ls,
            p.getInt("sc_$id", 100) / 100f,
            p.getInt("al_$id", 90) / 100f,
            p.getInt("ac_$id", 0)
        )
    }

    fun save(ctx: Context, id: Int, leagues: List<String>, scale: Int, alpha: Int, accent: Int) {
        sp(ctx).edit()
            .putString("lg_$id", leagues.joinToString(","))
            .putInt("sc_$id", scale)
            .putInt("al_$id", alpha)
            .putInt("ac_$id", accent)
            .apply()
    }

    fun delete(ctx: Context, id: Int) {
        sp(ctx).edit().remove("lg_$id").remove("sc_$id").remove("al_$id").remove("ac_$id").apply()
    }

    fun lastUpdate(ctx: Context): Long = sp(ctx).getLong("last", 0L)

    fun error(ctx: Context): String = sp(ctx).getString("err", "") ?: ""

    fun setError(ctx: Context, e: String) {
        sp(ctx).edit().putString("err", e).apply()
    }

    fun touch(ctx: Context) {
        sp(ctx).edit().putLong("last", System.currentTimeMillis()).apply()
    }

    fun putCache(ctx: Context, league: String, list: List<Match>) {
        val a = JSONArray()
        for (m in list) {
            val o = JSONObject()
            o.put("ts", m.ts)
            o.put("lg", m.league)
            o.put("h", m.home)
            o.put("a", m.away)
            o.put("ha", m.hAbbr)
            o.put("aa", m.aAbbr)
            o.put("hl", m.hLogo)
            o.put("al", m.aLogo)
            o.put("st", m.state)
            o.put("hs", m.hs)
            o.put("as", m.aS)
            o.put("ck", m.clock)
            a.put(o)
        }
        sp(ctx).edit().putString("c_$league", a.toString()).apply()
    }

    private fun cached(ctx: Context, league: String): List<Match> {
        val s = sp(ctx).getString("c_$league", null) ?: return emptyList()
        val out = ArrayList<Match>()
        try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    Match(
                        o.getLong("ts"), o.optString("lg"), o.optString("h"), o.optString("a"),
                        o.optString("ha"), o.optString("aa"), o.optString("hl"), o.optString("al"),
                        o.optString("st"), o.optString("hs"), o.optString("as"), o.optString("ck")
                    )
                )
            }
        } catch (e: Exception) {
        }
        return out
    }

    /** Ближайшие матчи по выбранным лигам: идущие сейчас и будущие, по времени. */
    fun upcoming(ctx: Context, leagues: List<String>): List<Match> {
        val now = System.currentTimeMillis()
        val all = ArrayList<Match>()
        for (l in leagues) all.addAll(cached(ctx, l))
        return all
            .filter { (it.state == "in" && it.ts > now - 3 * 3600_000L) || it.ts > now - 10 * 60_000L }
            .sortedBy { it.ts }
    }
}

object Football {
    private fun http(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) FootWidget")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun parseDate(s: String): Long? {
        for (pat in arrayOf("yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'")) {
            try {
                val f = SimpleDateFormat(pat, Locale.US)
                f.timeZone = TimeZone.getTimeZone("UTC")
                val d = f.parse(s)
                if (d != null) return d.time
            } catch (e: Exception) {
            }
        }
        return null
    }

    private fun teamName(t: JSONObject?): String {
        if (t == null) return ""
        val s = t.optString("shortDisplayName")
        return if (s.isNotEmpty()) s else t.optString("displayName")
    }

    private fun parse(league: String, txt: String): List<Match> {
        val out = ArrayList<Match>()
        val ev = JSONObject(txt).optJSONArray("events") ?: return out
        for (i in 0 until ev.length()) {
            val e = ev.getJSONObject(i)
            val ts = parseDate(e.optString("date")) ?: continue
            val st = e.optJSONObject("status")
            val state = st?.optJSONObject("type")?.optString("state") ?: "pre"
            if (state == "post") continue
            val clock = st?.optString("displayClock") ?: ""
            val comp = e.optJSONArray("competitions")?.optJSONObject(0) ?: continue
            val cs = comp.optJSONArray("competitors") ?: continue
            var h: JSONObject? = null
            var a: JSONObject? = null
            for (k in 0 until cs.length()) {
                val c = cs.getJSONObject(k)
                if (c.optString("homeAway") == "home") h = c else a = c
            }
            if (h == null || a == null) continue
            val ht = h.optJSONObject("team")
            val at = a.optJSONObject("team")
            out.add(
                Match(
                    ts, league, teamName(ht), teamName(at),
                    ht?.optString("abbreviation") ?: "", at?.optString("abbreviation") ?: "",
                    ht?.optString("logo") ?: "", at?.optString("logo") ?: "",
                    state, h.optString("score", "0"), a.optString("score", "0"), clock
                )
            )
        }
        out.sortBy { it.ts }
        return out
    }

    private fun fetch(league: String, query: String): List<Match> {
        val txt = http("https://site.api.espn.com/apis/site/v2/sports/soccer/$league/scoreboard$query")
        return parse(league, txt)
    }

    /** Загружает матчи лиги (без логотипов); true, если ответ получен и разобран. */
    fun refresh(ctx: Context, league: String): Boolean {
        val f = SimpleDateFormat("yyyyMMdd", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        val now = System.currentTimeMillis()
        val a = f.format(Date(now - 86400000L))
        val b = f.format(Date(now + 14 * 86400000L))
        // 1) диапазон дат; 2) запасной вариант — обычный scoreboard без параметров
        val tries = arrayOf("?dates=$a-$b&limit=200", "?limit=200", "")
        var lastErr = ""
        for (q in tries) {
            try {
                val list = fetch(league, q)
                Store.putCache(ctx, league, list)
                Store.setError(ctx, "")
                return true
            } catch (e: Exception) {
                lastErr = (e.javaClass.simpleName + ": " + (e.message ?: "")).take(80)
            }
        }
        Store.setError(ctx, lastErr)
        return false
    }

    fun loadLogos(ctx: Context, league: String) {
        try {
            val list = Store.upcoming(ctx, listOf(league))
            for (m in list.take(14)) {
                Logos.get(ctx, m.hLogo, true)
                Logos.get(ctx, m.aLogo, true)
            }
        } catch (e: Exception) {
        }
    }
}

object Logos {
    private fun file(ctx: Context, url: String) =
        File(ctx.cacheDir, "logo_" + Integer.toHexString(url.hashCode()) + ".png")

    fun get(ctx: Context, url: String, net: Boolean): Bitmap? {
        if (url.isEmpty()) return null
        val f = file(ctx, url)
        if (f.exists()) return BitmapFactory.decodeFile(f.path)
        if (!net) return null
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            val opt = BitmapFactory.Options()
            opt.inSampleSize = 4
            val raw = BitmapFactory.decodeStream(c.inputStream, null, opt)
            c.disconnect()
            if (raw == null) {
                null
            } else {
                val k = 96f / max(raw.width, raw.height)
                val bm = Bitmap.createScaledBitmap(
                    raw, max(1, (raw.width * k).toInt()), max(1, (raw.height * k).toInt()), true
                )
                f.outputStream().use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
                bm
            }
        } catch (e: Exception) {
            null
        }
    }
}
