package com.footwidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.max

class Match(
    val ts: Long,
    val league: String,
    val home: String,
    val away: String,
    val hAbbr: String,
    val aAbbr: String,
    val hLogo: String,
    val aLogo: String,
    val state: String,
    val hs: String,
    val aS: String,
    val clock: String,
    val id: String = "",
    val url: String = ""
)

class Settings(val leagues: List<String>, val scale: Float, val alpha: Float, val accent: Int, val mode: Int, val favs: String)

object Leagues {
    val list = listOf(
        "eng.1" to "Премьер-лига",
        "esp.1" to "Ла Лига",
        "ger.1" to "Бундеслига",
        "ita.1" to "Серия A",
        "fra.1" to "Лига 1",
        "uefa.champions" to "Лига чемпионов",
        "uefa.europa" to "Лига Европы",
        "rus.1" to "РПЛ",
        "fifa.world" to "Чемпионат мира"
    )

    fun name(slug: String): String = list.firstOrNull { it.first == slug }?.second ?: slug
}

object Teams {
    /** Русские названия популярных команд → как их называет ESPN. */
    val ru = mapOf(
        "арсенал" to "arsenal", "челси" to "chelsea", "ливерпуль" to "liverpool",
        "манчестер юнайтед" to "man united", "ман юнайтед" to "man united", "мю" to "man united",
        "манчестер сити" to "man city", "ман сити" to "man city", "сити" to "man city",
        "тоттенхэм" to "tottenham", "тоттенхем" to "tottenham", "ньюкасл" to "newcastle",
        "астон вилла" to "aston villa", "вест хэм" to "west ham", "эвертон" to "everton",
        "реал" to "real madrid", "реал мадрид" to "real madrid", "барселона" to "barcelona",
        "барса" to "barcelona", "атлетико" to "atl", "севилья" to "sevilla", "валенсия" to "valencia",
        "бавария" to "bayern", "дортмунд" to "dortmund", "боруссия дортмунд" to "dortmund",
        "лейпциг" to "leipzig", "леверкузен" to "leverkusen",
        "ювентус" to "juventus", "ювe" to "juventus", "милан" to "ac milan", "интер" to "inter",
        "наполи" to "napoli", "рома" to "roma", "лацио" to "lazio", "аталанта" to "atalanta",
        "псж" to "psg", "марсель" to "marseille", "монако" to "monaco", "лион" to "lyon",
        "зенит" to "zenit", "спартак" to "spartak", "цска" to "cska", "локомотив" to "lokomotiv",
        "краснодар" to "krasnodar", "динамо" to "dynamo", "ростов" to "rostov",
        "аякс" to "ajax", "бенфика" to "benfica", "порту" to "porto",
        "россия" to "russia", "франция" to "france", "германия" to "germany", "испания" to "spain",
        "англия" to "england", "бразилия" to "brazil", "аргентина" to "argentina",
        "италия" to "italy", "португалия" to "portugal", "нидерланды" to "netherlands"
    )
}

object Store {
    private fun sp(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("foot", Context.MODE_PRIVATE)

    fun load(ctx: Context, id: Int): Settings {
        val p = sp(ctx)
        val ls = (p.getString("lg_$id", "eng.1") ?: "eng.1").split(",").filter { it.isNotEmpty() }
        return Settings(
            if (ls.isEmpty()) listOf("eng.1") else ls,
            p.getInt("sc_$id", 100) / 100f,
            p.getInt("al_$id", 90) / 100f,
            p.getInt("ac_$id", 0),
            p.getInt("md_$id", 0),
            p.getString("fv_$id", "") ?: ""
        )
    }

    fun save(ctx: Context, id: Int, leagues: List<String>, scale: Int, alpha: Int, accent: Int, mode: Int, favs: String) {
        sp(ctx).edit()
            .putString("lg_$id", leagues.joinToString(","))
            .putInt("sc_$id", scale)
            .putInt("al_$id", alpha)
            .putInt("ac_$id", accent)
            .putInt("md_$id", mode)
            .putString("fv_$id", favs)
            .putInt("pg_$id", 0)
            .apply()
    }

    fun delete(ctx: Context, id: Int) {
        sp(ctx).edit().remove("lg_$id").remove("sc_$id").remove("al_$id").remove("ac_$id")
            .remove("pg_$id").remove("pc_$id").remove("md_$id").remove("fv_$id").apply()
    }

    fun mode(ctx: Context, id: Int): Int = sp(ctx).getInt("md_$id", 0)

    fun setMode(ctx: Context, id: Int, v: Int) {
        sp(ctx).edit().putInt("md_$id", v).apply()
    }

    fun page(ctx: Context, id: Int): Int = sp(ctx).getInt("pg_$id", 0)

    fun setPage(ctx: Context, id: Int, v: Int) {
        sp(ctx).edit().putInt("pg_$id", v).apply()
    }

    fun pageCount(ctx: Context, id: Int): Int = sp(ctx).getInt("pc_$id", 1)

    fun setPageCount(ctx: Context, id: Int, v: Int) {
        sp(ctx).edit().putInt("pc_$id", v).apply()
    }

    fun lastUpdate(ctx: Context): Long = sp(ctx).getLong("last", 0L)

    fun error(ctx: Context): String = sp(ctx).getString("err", "") ?: ""

    fun setError(ctx: Context, e: String) {
        sp(ctx).edit().putString("err", e).apply()
    }

    fun touch(ctx: Context) {
        sp(ctx).edit().putLong("last", System.currentTimeMillis()).apply()
    }

    fun putCache(ctx: Context, league: String, list: List<Match>) {
        val a = JSONArray()
        for (m in list) {
            val o = JSONObject()
            o.put("ts", m.ts)
            o.put("lg", m.league)
            o.put("h", m.home)
            o.put("a", m.away)
            o.put("ha", m.hAbbr)
            o.put("aa", m.aAbbr)
            o.put("hl", m.hLogo)
            o.put("al", m.aLogo)
            o.put("st", m.state)
            o.put("hs", m.hs)
            o.put("as", m.aS)
            o.put("ck", m.clock)
            o.put("id", m.id)
            o.put("u", m.url)
            a.put(o)
        }
        sp(ctx).edit().putString("c_$league", a.toString()).apply()
    }

    private fun cached(ctx: Context, league: String): List<Match> {
        val s = sp(ctx).getString("c_$league", null) ?: return emptyList()
        val out = ArrayList<Match>()
        try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    Match(
                        o.getLong("ts"), o.optString("lg"), o.optString("h"), o.optString("a"),
                        o.optString("ha"), o.optString("aa"), o.optString("hl"), o.optString("al"),
                        o.optString("st"), o.optString("hs"), o.optString("as"), o.optString("ck"),
                        o.optString("id"), o.optString("u")
                    )
                )
            }
        } catch (e: Exception) {
        }
        return out
    }

    /** Избранные команды: через запятую, по-русски или по-английски («Арсенал, Man United, PSG»). */
    fun favTokens(raw: String): List<String> =
        raw.split(",", ";", "\n").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            .map { Teams.ru[it] ?: it }

    fun applyFavs(list: List<Match>, raw: String): List<Match> {
        val toks = favTokens(raw)
        if (toks.isEmpty()) return list
        return list.filter { m ->
            val h = m.home.lowercase()
            val a = m.away.lowercase()
            toks.any { t ->
                h.contains(t) || a.contains(t) ||
                    m.hAbbr.lowercase() == t || m.aAbbr.lowercase() == t
            }
        }
    }

    fun key(m: Match): String =
        if (m.id.isNotEmpty()) m.id else m.ts.toString() + m.hAbbr + m.aAbbr

    /** Ближайшие матчи по выбранным лигам: идущие сейчас и будущие, по времени. */
    fun upcoming(ctx: Context, leagues: List<String>): List<Match> {
        val now = System.currentTimeMillis()
        val all = ArrayList<Match>()
        for (l in leagues) all.addAll(cached(ctx, l))
        return all
            .filter {
                it.state != "post" &&
                    ((it.state == "in" && it.ts > now - 4 * 3600_000L) || it.ts > now - 10 * 60_000L)
            }
            .sortedBy { it.ts }
    }

    /** Завершённые матчи за последние ~10 дней, свежие сверху. */
    fun results(ctx: Context, leagues: List<String>): List<Match> {
        val now = System.currentTimeMillis()
        val all = ArrayList<Match>()
        for (l in leagues) all.addAll(cached(ctx, l))
        return all
            .filter { it.state == "post" && it.ts > now - 10 * 86400_000L }
            .sortedByDescending { it.ts }
    }

    /** Добавляет свежие данные (live-обновление) к кэшу, не стирая остальное. */
    fun mergeCache(ctx: Context, league: String, fresh: List<Match>) {
        val now = System.currentTimeMillis()
        val freshTs = HashSet<String>()
        for (m in fresh) freshTs.add(m.ts.toString() + m.hAbbr + m.aAbbr)
        val map = LinkedHashMap<String, Match>()
        for (m in cached(ctx, league)) {
            if (m.id.isEmpty() && freshTs.contains(key(m))) continue
            map[key(m)] = m
        }
        for (m in fresh) map[key(m)] = m
        putCache(ctx, league, map.values.filter { it.ts > now - 12 * 86400_000L }.sortedBy { it.ts })
    }

    /** Когда в следующий раз обновлять: раз в минуту во время матча, иначе к началу ближайшего. */
    fun nextTick(ctx: Context, leagues: List<String>, now: Long): Long? {
        val all = ArrayList<Match>()
        for (l in leagues) all.addAll(cached(ctx, l))
        if (all.any { it.state == "in" && it.ts > now - 4 * 3600_000L }) return now + 60_000L
        val next = all.filter { it.state == "pre" && it.ts > now - 3 * 3600_000L }
            .minByOrNull { it.ts } ?: return null
        if (next.ts - now > 6 * 3600_000L) return null
        return if (next.ts < now) now + 60_000L else max(next.ts + 30_000L, now + 30_000L)
    }
}

object Football {
    private fun http(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) FootWidget")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun parseDate(s: String): Long? {
        for (pat in arrayOf("yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'")) {
            try {
                val f = SimpleDateFormat(pat, Locale.US)
                f.timeZone = TimeZone.getTimeZone("UTC")
                val d = f.parse(s)
                if (d != null) return d.time
            } catch (e: Exception) {
            }
        }
        return null
    }

    private fun teamName(t: JSONObject?): String {
        if (t == null) return ""
        val s = t.optString("shortDisplayName")
        return if (s.isNotEmpty()) s else t.optString("displayName")
    }

    private fun matchUrl(e: JSONObject, id: String): String {
        val ls = e.optJSONArray("links")
        if (ls != null) {
            var first = ""
            for (i in 0 until ls.length()) {
                val l = ls.optJSONObject(i) ?: continue
                val href = l.optString("href")
                if (href.isEmpty()) continue
                if (first.isEmpty()) first = href
                val rel = l.optJSONArray("rel")
                if (rel != null) {
                    for (j in 0 until rel.length()) if (rel.optString(j) == "summary") return href
                }
            }
            if (first.isNotEmpty()) return first
        }
        return if (id.isNotEmpty()) "https://www.espn.com/soccer/match/_/gameId/$id" else ""
    }

    private fun parse(league: String, txt: String): List<Match> {
        val out = ArrayList<Match>()
        val ev = JSONObject(txt).optJSONArray("events") ?: return out
        for (i in 0 until ev.length()) {
            val e = ev.getJSONObject(i)
            val ts = parseDate(e.optString("date")) ?: continue
            val st = e.optJSONObject("status")
            val state = st?.optJSONObject("type")?.optString("state") ?: "pre"
            val tname = st?.optJSONObject("type")?.optString("name") ?: ""
            if (tname.contains("POSTPONED") || tname.contains("CANCEL")) continue
            var clock = st?.optString("displayClock") ?: ""
            if (tname == "STATUS_HALFTIME") clock = "перерыв"
            val eid = e.optString("id")
            val comp = e.optJSONArray("competitions")?.optJSONObject(0) ?: continue
            val cs = comp.optJSONArray("competitors") ?: continue
            var h: JSONObject? = null
            var a: JSONObject? = null
            for (k in 0 until cs.length()) {
                val c = cs.getJSONObject(k)
                if (c.optString("homeAway") == "home") h = c else a = c
            }
            if (h == null || a == null) continue
            val ht = h.optJSONObject("team")
            val at = a.optJSONObject("team")
            out.add(
                Match(
                    ts, league, teamName(ht), teamName(at),
                    ht?.optString("abbreviation") ?: "", at?.optString("abbreviation") ?: "",
                    ht?.optString("logo") ?: "", at?.optString("logo") ?: "",
                    state, h.optString("score", "0"), a.optString("score", "0"), clock,
                    eid, matchUrl(e, eid)
                )
            )
        }
        out.sortBy { it.ts }
        return out
    }

    private fun fetch(league: String, query: String): List<Match> {
        val txt = http("https://site.api.espn.com/apis/site/v2/sports/soccer/$league/scoreboard$query")
        return parse(league, txt)
    }

    /**
     * Загружает матчи лиги (без логотипов). Основной способ — отдельный запрос на каждый день
     * (вчера … +10 дней): ESPN надёжно отдаёт именно один день, а диапазон и запрос без дат
     * могут вернуть только ближайший игровой день. Запасные варианты — диапазон и обычный scoreboard.
     */
    fun refresh(ctx: Context, league: String): Boolean {
        val f = SimpleDateFormat("yyyyMMdd", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        val now = System.currentTimeMillis()
        val days = (-4..10).map { f.format(Date(now + it * 86400000L)) }

        // 1) по одному запросу на день, параллельно
        val pool = java.util.concurrent.Executors.newFixedThreadPool(6)
        val merged = LinkedHashMap<String, Match>()
        var got = 0
        var lastErr = ""
        try {
            val futures = days.map { day ->
                pool.submit(java.util.concurrent.Callable<List<Match>?> {
                    try {
                        fetch(league, "?dates=$day&limit=200")
                    } catch (e: Exception) {
                        lastErr = (e.javaClass.simpleName + ": " + (e.message ?: "")).take(80)
                        null
                    }
                })
            }
            for (fu in futures) {
                val r = try { fu.get() } catch (e: Exception) { null }
                if (r != null) {
                    got++
                    for (m in r) merged[Store.key(m)] = m
                }
            }
        } finally {
            pool.shutdown()
        }
        if (got > 0) {
            Store.putCache(ctx, league, merged.values.sortedBy { it.ts })
            Store.setError(ctx, "")
            return true
        }

        // 2) запасные варианты
        val a = days.first()
        val b = days.last()
        for (q in arrayOf("?dates=$a-$b&limit=200", "?limit=200", "")) {
            try {
                val list = fetch(league, q)
                Store.putCache(ctx, league, list)
                Store.setError(ctx, "")
                return true
            } catch (e: Exception) {
                lastErr = (e.javaClass.simpleName + ": " + (e.message ?: "")).take(80)
            }
        }
        Store.setError(ctx, lastErr)
        return false
    }

    /** Лёгкое обновление для живого счёта: только вчера/сегодня/завтра. */
    fun refreshLive(ctx: Context, league: String): Boolean {
        val f = SimpleDateFormat("yyyyMMdd", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        val now = System.currentTimeMillis()
        val days = (-1..1).map { f.format(Date(now + it * 86400000L)) }
        val pool = java.util.concurrent.Executors.newFixedThreadPool(3)
        val fresh = ArrayList<Match>()
        var got = 0
        try {
            val futures = days.map { day ->
                pool.submit(java.util.concurrent.Callable<List<Match>?> {
                    try {
                        fetch(league, "?dates=$day&limit=200")
                    } catch (e: Exception) {
                        null
                    }
                })
            }
            for (fu in futures) {
                val r = try { fu.get() } catch (e: Exception) { null }
                if (r != null) {
                    got++
                    fresh.addAll(r)
                }
            }
        } finally {
            pool.shutdown()
        }
        if (got == 0) return false
        Store.mergeCache(ctx, league, fresh)
        Store.setError(ctx, "")
        return true
    }

    fun loadLogos(ctx: Context, league: String) {
        try {
            val list = Store.upcoming(ctx, listOf(league)).take(14) + Store.results(ctx, listOf(league)).take(10)
            for (m in list) {
                Logos.get(ctx, m.hLogo, true)
                Logos.get(ctx, m.aLogo, true)
            }
        } catch (e: Exception) {
        }
    }
}

object Logos {
    private fun file(ctx: Context, url: String) =
        File(ctx.cacheDir, "logo_" + Integer.toHexString(url.hashCode()) + ".png")

    fun get(ctx: Context, url: String, net: Boolean): Bitmap? {
        if (url.isEmpty()) return null
        val f = file(ctx, url)
        if (f.exists()) return BitmapFactory.decodeFile(f.path)
        if (!net) return null
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            val opt = BitmapFactory.Options()
            opt.inSampleSize = 4
            val raw = BitmapFactory.decodeStream(c.inputStream, null, opt)
            c.disconnect()
            if (raw == null) {
                null
            } else {
                val k = 96f / max(raw.width, raw.height)
                val bm = Bitmap.createScaledBitmap(
                    raw, max(1, (raw.width * k).toInt()), max(1, (raw.height * k).toInt()), true
                )
                f.outputStream().use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
                bm
            }
        } catch (e: Exception) {
            null
        }
    }
}
